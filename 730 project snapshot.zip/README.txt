Team 23 members

Name:	Paul Waycuilis
netID:	pkw20
e-mail:	pkw20@txstate.edu

Name:	Victor Hernandez
netID:	v_h74
email:	vichdz97@txstate.edu


Project is not finished. In an effort to submit something somewhat working and coherent,
the program version submitted only handles R type instructions,
and does not handle hazards. 

Also cycles data quicker than the sample output and cache data output 
is 1 cycle behind other output. 

MEM unit not working.
Also does not handle instructions that are not R type instrs


ALSO: no working mechanism to end cycle, so it is manually set to cycle 12 times